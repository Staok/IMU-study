var searchData=
[
  ['register_5fcache',['register_cache',['../a00010.html#ad4da7268d90cbb82f85fc0baa5b75770',1,'inv_icm426xx_transport']]],
  ['reserved',['reserved',['../a00002.html#a35de734d6638901060bad7a6d3c6c887',1,'inv_icm426xx']]]
];
