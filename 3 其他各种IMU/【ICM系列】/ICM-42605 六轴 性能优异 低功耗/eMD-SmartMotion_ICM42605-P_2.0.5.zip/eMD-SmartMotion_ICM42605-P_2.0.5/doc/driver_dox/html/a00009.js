var a00009 =
[
    [ "max_peak_tol", "a00009.html#a0396dd628fece1cfc3f0767acebe82b3", null ],
    [ "min_jerk_thr", "a00009.html#ad5a5aef9818f530f70446a045beecb5b", null ],
    [ "tavg", "a00009.html#a97221d53b4c392b9050914ee46be1294", null ],
    [ "tmax", "a00009.html#add629a24c3f39c970637d6e0a975df08", null ],
    [ "tmin", "a00009.html#a992c04338b4e4ff8168422a1551c53fc", null ]
];