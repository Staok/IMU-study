var searchData=
[
  ['intf_5fcfg_5f1_5freg',['intf_cfg_1_reg',['../a00012.html#a049893a073168c46f02848c569570f9c',1,'inv_icm426xx_transport::register_cache']]]
];
