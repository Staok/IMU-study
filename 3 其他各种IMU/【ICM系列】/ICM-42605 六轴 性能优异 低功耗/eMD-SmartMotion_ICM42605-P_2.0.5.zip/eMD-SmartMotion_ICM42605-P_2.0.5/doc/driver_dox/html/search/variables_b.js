var searchData=
[
  ['sensitivity_5fmode',['sensitivity_mode',['../a00003.html#aabac64d18a4a3dfb0daba983469fd0e2',1,'inv_icm426xx_apex_parameters']]],
  ['sensor_5fevent_5fcb',['sensor_event_cb',['../a00002.html#ab510d48d30cb92123c4de6c849eafaff',1,'inv_icm426xx']]],
  ['serif',['serif',['../a00010.html#ade989af3ef6b1ea627e3982e7cc5951f',1,'inv_icm426xx_transport']]],
  ['st_5fresult',['st_result',['../a00002.html#aef28bfd8c914080b543d8f79075ebefd',1,'inv_icm426xx']]],
  ['step_5fcadence',['step_cadence',['../a00004.html#ae54efd252e767b3c9fb8f460833a4aa8',1,'inv_icm426xx_apex_step_activity']]],
  ['step_5fcnt',['step_cnt',['../a00004.html#a72e853bcaba8ab19b2153ffec672b997',1,'inv_icm426xx_apex_step_activity']]]
];
