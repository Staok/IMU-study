var a00008 =
[
    [ "double_tap_timing", "a00008.html#abd48fc5af17c55ba4a37127f33cd6631", null ],
    [ "tap_axis", "a00008.html#a8838b170e8b57590c250cfb1057ec2fd", null ],
    [ "tap_dir", "a00008.html#a33b0b8d241882f05ce75b8827631dc29", null ],
    [ "tap_num", "a00008.html#ab3c6e310f09a015d9a7e681c4220bf72", null ]
];