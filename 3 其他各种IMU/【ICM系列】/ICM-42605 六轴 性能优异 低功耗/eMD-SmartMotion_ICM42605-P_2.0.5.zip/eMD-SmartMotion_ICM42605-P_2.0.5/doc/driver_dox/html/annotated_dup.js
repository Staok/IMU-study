var annotated_dup =
[
    [ "fifo_header_t", "a00001.html", null ],
    [ "inv_icm426xx", "a00002.html", "a00002" ],
    [ "inv_icm426xx_apex_parameters", "a00003.html", "a00003" ],
    [ "inv_icm426xx_apex_step_activity", "a00004.html", "a00004" ],
    [ "inv_icm426xx_interrupt_parameter_t", "a00005.html", null ],
    [ "inv_icm426xx_sensor_event_t", "a00006.html", null ],
    [ "inv_icm426xx_serif", "a00007.html", null ],
    [ "inv_icm426xx_tap_data", "a00008.html", "a00008" ],
    [ "inv_icm426xx_tap_parameters_t", "a00009.html", "a00009" ],
    [ "inv_icm426xx_transport", "a00010.html", "a00010" ],
    [ "recover_regs", "a00011.html", null ]
];