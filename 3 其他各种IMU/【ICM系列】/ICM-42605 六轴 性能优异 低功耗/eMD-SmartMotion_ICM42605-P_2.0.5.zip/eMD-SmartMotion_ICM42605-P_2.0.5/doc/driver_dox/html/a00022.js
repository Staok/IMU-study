var a00022 =
[
    [ "register_cache", "a00012.html", "a00012" ],
    [ "ICM426XX_SERIAL_IF_TYPE_t", "a00027.html#ga3d283288ecb8f886ee1f86fd7b082f44", null ],
    [ "inv_icm426xx_init_transport", "a00027.html#ga7b3e27bda54aaa605060ae4b0fcca743", null ],
    [ "inv_icm426xx_read_reg", "a00027.html#ga30f009e054ad56fb78d6ef549f72b192", null ],
    [ "inv_icm426xx_write_reg", "a00027.html#gae1815fab11898a827726d261aeb23a0f", null ]
];