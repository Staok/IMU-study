var a00117 =
[
    [ "inv_device_icm20603", "a00018.html", null ],
    [ "inv_device_icm20603_config_bias_st", "a00019.html", [
      [ "acc_bias_lp", "a00019.html#a53dfff787229da4249cf4c369b5a9755", null ],
      [ "acc_bias_nl", "a00019.html#a1b4088b460ee143813e9cbf431c64a5a", null ],
      [ "gyr_bias_lp", "a00019.html#aa2a67ca2af7288dc6f5c306708fcd4c1", null ],
      [ "gyr_bias_nl", "a00019.html#ab7817f1c8d5b1c0ba8f056b10b739189", null ]
    ] ],
    [ "inv_device_icm20603_config_bias_st_t", "a00117.html#ga08609a327b82c1be0959517f363750a9", null ],
    [ "inv_device_icm20603_config_wom_threshold_t", "a00117.html#ga0f78d09cdbcd486f2a0bf7c420b7ce2a", null ],
    [ "inv_device_icm20603_t", "a00117.html#gaaa87dfb2ac4adf4d2d4a946382dd6d49", null ],
    [ "inv_device_icm20603_config", "a00117.html#ga8ca912665b9c374042dabd82f76e918e", null ],
    [ "inv_device_icm20603_get_base", "a00117.html#ga338e69c9c488c8e41bd7db205f951570", null ],
    [ "inv_device_icm20603_init", "a00117.html#ga77b953801ffede4baf5174fc953fdcaa", null ],
    [ "inv_device_icm20603_init2", "a00117.html#gaf943c11d60dcd95ebe9739cf2f871f8f", null ],
    [ "inv_device_icm20603_init_aux_compass", "a00117.html#ga46f9e4fa0f7fdf96e4ef24a569f453b6", null ],
    [ "inv_device_icm20603_init_serif_ois", "a00117.html#ga8bd232c836b58d0d73b4fa06526d1e8c", null ],
    [ "inv_device_icm20603_init_serif_ois2", "a00117.html#ga7fa599d99b08d78b44fe74c86c419d98", null ]
];