var a00132 =
[
    [ "COMPASS_I2C_SLV_READ", "a00132.html#ga94025fcc78d7b0214c9ea6cf978987a6", null ],
    [ "inv_icm20603_execute_read_secondary", "a00132.html#ga95e330bb677441e77b2ceec2de7dd93d", null ],
    [ "inv_icm20603_execute_write_secondary", "a00132.html#gaa43cde3e6f79330f656c24f263ad22b4", null ],
    [ "inv_icm20603_init_secondary", "a00132.html#ga70cfe6f919f5e9f7320897c49c775201", null ],
    [ "inv_icm20603_read_secondary", "a00132.html#ga3c947b4fd71639230a9d7adffd8291bb", null ],
    [ "inv_icm20603_secondary_disable_i2c", "a00132.html#ga47f878db4679899aa415ce66670f4edf", null ],
    [ "inv_icm20603_secondary_enable_i2c", "a00132.html#ga18f1595a34cb897251479d58a6483e62", null ],
    [ "inv_icm20603_secondary_stop_channel", "a00132.html#ga2735839a59d1ba7538be58e8c348c08a", null ],
    [ "inv_icm20603_write_secondary", "a00132.html#gac4fdffac84d24b280ec870b04d098295", null ]
];