var a00125 =
[
    [ "COMPASS_I2C_SLV_READ", "a00125.html#ga94025fcc78d7b0214c9ea6cf978987a6", null ],
    [ "inv_icm20602_execute_read_secondary", "a00125.html#ga50786e16bc7e89368de5aec575f9a5f8", null ],
    [ "inv_icm20602_execute_write_secondary", "a00125.html#ga4d5c547ad3d6fa38c5f30a73f435c1dd", null ],
    [ "inv_icm20602_init_secondary", "a00125.html#gacc2c6baf6f229c2ec8cae73a131d86b3", null ],
    [ "inv_icm20602_read_secondary", "a00125.html#gab1e3ae4f0a66415cab91450e67946224", null ],
    [ "inv_icm20602_secondary_disable_i2c", "a00125.html#gaa987fc356dcd9ab9945df23d9a26e2d1", null ],
    [ "inv_icm20602_secondary_enable_i2c", "a00125.html#ga7229877a47ad1ead7ea5e5afc2960d91", null ],
    [ "inv_icm20602_secondary_stop_channel", "a00125.html#ga828b3a7129f98bcfe3d657d5a2612458", null ],
    [ "inv_icm20602_write_secondary", "a00125.html#gafd62a71736bdc3501237d18b3486db46", null ]
];