var examples =
[
    [ "ExampleDeviceIcm20602EMD.c", "a00005.html", null ],
    [ "ExampleDeviceIcm20603EMD.c", "a00007.html", null ],
    [ "ExampleDeviceIcm20690EMD.c", "a00009.html", null ],
    [ "ExampleSerifHal.c", "a00003.html", null ]
];