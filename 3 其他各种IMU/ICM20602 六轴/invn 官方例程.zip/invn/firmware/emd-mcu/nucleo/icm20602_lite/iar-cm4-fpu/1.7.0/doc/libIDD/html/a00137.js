var a00137 =
[
    [ "Icm20690 akm compass support", "a00138.html", "a00138" ],
    [ "Icm20690 secondary driver transport", "a00139.html", "a00139" ],
    [ "Icm20690 control", "a00140.html", "a00140" ],
    [ "Icm20690 driver serif", "a00141.html", "a00141" ],
    [ "Icm20690 driver setup", "a00142.html", "a00142" ],
    [ "Icm20690 driver transport", "a00143.html", "a00143" ],
    [ "inv_icm20690", "a00040.html", [
      [ "inv_icm20690_secondary_states", "a00043.html", [
        [ "inv_icm20690_secondary_reg", "a00042.html", null ]
      ] ],
      [ "inv_icm20690_states", "a00045.html", null ]
    ] ],
    [ "inv_icm20690_t", "a00137.html#ga2edb5a89fb99c2c7529df1cc45f7fb6b", null ],
    [ "inv_icm20690_get_dataready_interrupt_time_us", "a00137.html#gac5c8063e940981be98680a96d5f22dd1", null ],
    [ "inv_icm20690_get_time_us", "a00137.html#ga074931a0fcde9a174be7f7d851411c44", null ],
    [ "inv_icm20690_reset_states", "a00137.html#ga406648fe74824ea8f9ac174db6c73529", null ],
    [ "inv_icm20690_reset_states_serif_ois", "a00137.html#ga144a3ab69c696fa57320b2f0370294a8", null ],
    [ "inv_icm20690_sleep", "a00137.html#ga534261e7c0dab6d2274dc635ab85f75f", null ],
    [ "inv_icm20690_sleep_us", "a00137.html#ga9d49815bc7e4595354cf91a2673a53dd", null ]
];