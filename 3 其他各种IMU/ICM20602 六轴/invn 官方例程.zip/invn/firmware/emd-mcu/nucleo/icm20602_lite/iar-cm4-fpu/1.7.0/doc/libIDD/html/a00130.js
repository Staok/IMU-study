var a00130 =
[
    [ "Icm20603 akm compass support", "a00131.html", "a00131" ],
    [ "Icm20603 secondary driver transport", "a00132.html", "a00132" ],
    [ "Icm20603 control", "a00133.html", "a00133" ],
    [ "Icm20603 driver serif", "a00134.html", "a00134" ],
    [ "Icm20603 driver setup", "a00135.html", "a00135" ],
    [ "Icm20603 driver transport", "a00136.html", "a00136" ],
    [ "inv_icm20603", "a00034.html", [
      [ "inv_icm20603_secondary_states", "a00037.html", [
        [ "inv_icm20603_secondary_reg", "a00036.html", null ]
      ] ],
      [ "inv_icm20603_states", "a00039.html", null ]
    ] ],
    [ "inv_icm20603_t", "a00130.html#ga98978291852cb92b795898c436a0a41c", null ],
    [ "inv_icm20603_get_dataready_interrupt_time_us", "a00130.html#ga56e412511e5a51e2b6e34d0d23d320d6", null ],
    [ "inv_icm20603_get_time_us", "a00130.html#ga2b2a8d6c7ab1b291592ef0c319b12eba", null ],
    [ "inv_icm20603_reset_states", "a00130.html#ga470bcea0c4d7d0bd9cd533dd6c67765a", null ],
    [ "inv_icm20603_reset_states_serif_ois", "a00130.html#ga6161a7f78cf40832c3aed7010c2f2049", null ],
    [ "inv_icm20603_sleep", "a00130.html#ga6e23f55f47a627cc3e93d8c302bf63a2", null ],
    [ "inv_icm20603_sleep_us", "a00130.html#ga4e192de672db262f7db3fe7d3365f059", null ]
];