var a00123 =
[
    [ "Icm20602 akm compass support", "a00124.html", "a00124" ],
    [ "Icm20602 secondary driver transport", "a00125.html", "a00125" ],
    [ "Icm20602 control", "a00126.html", "a00126" ],
    [ "Icm20602 driver serif", "a00127.html", "a00127" ],
    [ "Icm20602 driver setup", "a00128.html", "a00128" ],
    [ "Icm20602 driver transport", "a00129.html", "a00129" ],
    [ "inv_icm20602", "a00028.html", [
      [ "inv_icm20602_secondary_states", "a00031.html", [
        [ "inv_icm20602_secondary_reg", "a00030.html", null ]
      ] ],
      [ "inv_icm20602_states", "a00033.html", null ]
    ] ],
    [ "inv_icm20602_t", "a00123.html#ga6165b44db8765e5e9ee5cef6970a13a9", null ],
    [ "inv_icm20602_get_dataready_interrupt_time_us", "a00123.html#ga08bc64aa2bbc49370cec2b79a6e95870", null ],
    [ "inv_icm20602_get_time_us", "a00123.html#gaabdeca7885b8e04b5c9261fcc4d48769", null ],
    [ "inv_icm20602_reset_states", "a00123.html#ga3d794157699c953a46b9071d763aa703", null ],
    [ "inv_icm20602_reset_states_serif_ois", "a00123.html#ga5bda8980c32719b6d2b1e988e89972da", null ],
    [ "inv_icm20602_sleep", "a00123.html#ga55fea83a7c5ec2cf5772f445cc0b900c", null ],
    [ "inv_icm20602_sleep_us", "a00123.html#ga0e9788e308356063f3eb980cedae01ba", null ]
];