var a00115 =
[
    [ "inv_device_emd_wrap_icm20xxx", "a00014.html", null ],
    [ "inv_device_emd_wrap_icm20xxx_serial", "a00015.html", null ],
    [ "inv_device_emd_wrap_icm20xxx_init", "a00115.html#gaf9f8717b6d52ea09b38752ff1351b4e1", null ]
];