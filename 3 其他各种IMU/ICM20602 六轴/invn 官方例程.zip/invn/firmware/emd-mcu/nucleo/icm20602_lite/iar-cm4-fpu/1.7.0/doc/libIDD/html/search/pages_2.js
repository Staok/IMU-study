var searchData=
[
  ['supported_20devices',['Supported devices',['../a00011.html',1,'']]]
];
