var a00116 =
[
    [ "inv_device_icm20602", "a00016.html", null ],
    [ "inv_device_icm20602_config_bias_st", "a00017.html", [
      [ "acc_bias_lp", "a00017.html#ad070e4af5725103059804053de84b8e8", null ],
      [ "acc_bias_nl", "a00017.html#ae07e88c3794c2578a80507b6458e8fe4", null ],
      [ "gyr_bias_lp", "a00017.html#a7ab528baa25a74eea3b0fe9e1698cc96", null ],
      [ "gyr_bias_nl", "a00017.html#a20e5c1378ad2195597fa1cddf0b9ac3d", null ]
    ] ],
    [ "inv_device_icm20602_config_bias_st_t", "a00116.html#gab2f5cb5ae8e8c824849cc7479e4e9242", null ],
    [ "inv_device_icm20602_config_wom_threshold_t", "a00116.html#gaefe46253c1aca18a4ba0e871d244dbf9", null ],
    [ "inv_device_icm20602_t", "a00116.html#gafe1e166d017c94ce7bdb31b75e522a74", null ],
    [ "inv_device_icm20602_config", "a00116.html#ga2d9f179444b2a992fcf5353070e182e7", null ],
    [ "inv_device_icm20602_get_base", "a00116.html#gad401e39806862bc4122c638d6ed92868", null ],
    [ "inv_device_icm20602_init", "a00116.html#ga63d2f881304ff563f6b8fc0a9187bd43", null ],
    [ "inv_device_icm20602_init2", "a00116.html#ga3d4994bdabdc303c6881bff78c430170", null ],
    [ "inv_device_icm20602_init_aux_compass", "a00116.html#gae32432c7eb31d310cd318e0fc993e5a9", null ],
    [ "inv_device_icm20602_init_serif_ois", "a00116.html#ga1f13a5c505e9420fe37b00941774ecbe", null ],
    [ "inv_device_icm20602_init_serif_ois2", "a00116.html#ga0153477c3f274e1d9d84389ff5f902f2", null ]
];