#ifndef __gpio_H
#define __gpio_H
#include "stm32f10x.h"


void My_GPIO_Init(void);


#endif 

